# WA Ban Checker (Android)

A simple Android diagnostic app. It validates international phone-number format and provides links to WhatsApp and its official account recovery/contact page. It does **not** claim to query WhatsApp ban status or scan arbitrary numbers.

## Build
- Android Studio (recent stable)
- JDK 17
- Android SDK Platform 35

Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).

CLI (with Android SDK/Gradle installed): `gradle assembleDebug`
APK output: `app/build/outputs/apk/debug/app-debug.apk`
