package com.axiom.wabanchecker;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText phone;
    TextView result;
    LinearLayout root;
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    void button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(10); root.addView(b,p);
    }
    void open(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception e) { Toast.makeText(this,"Tidak ada aplikasi/browser untuk membuka tautan",Toast.LENGTH_SHORT).show(); } }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this); root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(28),dp(22),dp(24)); root.setBackgroundColor(Color.rgb(16,27,36)); scroll.addView(root); setContentView(scroll);
        root.addView(text("WA BAN CHECKER",24,Color.WHITE,true));
        TextView sub=text("Diagnostik akun WhatsApp",14,Color.rgb(165,190,199),false); sub.setPadding(0,dp(5),0,dp(22)); root.addView(sub);
        TextView info=text("Checker ini tidak mengakses server WhatsApp untuk memeriksa ban nomor secara otomatis. Gunakan untuk validasi nomor dan panduan diagnosis akun Anda.",14,Color.WHITE,false); info.setPadding(dp(14),dp(14),dp(14),dp(14)); info.setBackgroundColor(Color.rgb(31,47,59)); root.addView(info);
        root.addView(text("Nomor WhatsApp",16,Color.WHITE,true));
        phone=new EditText(this); phone.setSingleLine(true); phone.setHint("Contoh: +628123456789"); phone.setInputType(3); phone.setTextColor(Color.WHITE); phone.setHintTextColor(Color.GRAY); root.addView(phone);
        button("Validasi nomor", () -> {
            String n=phone.getText().toString().replaceAll("[\\s()-]", "");
            if(n.startsWith("00")) n="+"+n.substring(2);
            if(n.startsWith("0")) n="+62"+n.substring(1);
            if(!n.matches("\\+[1-9][0-9]{7,14}")) { result.setText("Format nomor tidak valid. Gunakan format internasional, misalnya +628123456789."); return; }
            phone.setText(n); result.setText("Format nomor valid: "+n+"\n\nStatus ban: TIDAK DAPAT DIVERIFIKASI OTOMATIS. Buka WhatsApp pada perangkat pemilik nomor untuk melihat pesan status akun.");
        });
        result=text("Hasil diagnosis akan muncul di sini.",14,Color.WHITE,false); result.setPadding(dp(14),dp(14),dp(14),dp(14)); result.setBackgroundColor(Color.rgb(31,47,59)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.topMargin=dp(14); root.addView(result,rp);
        button("Buka WhatsApp", () -> { String n=phone.getText().toString().replaceAll("[^0-9]",""); if(n.isEmpty()) { Toast.makeText(this,"Masukkan nomor terlebih dahulu",Toast.LENGTH_SHORT).show(); return; } open("https://wa.me/"+n); });
        button("Ajukan pemulihan akun", () -> open("https://www.whatsapp.com/contact/"));
        TextView steps=text("Panduan:\n1. Buka WhatsApp di perangkat pemilik akun.\n2. Catat pesan yang muncul saat login.\n3. Jika tertulis akun tidak diizinkan menggunakan WhatsApp, gunakan opsi Minta peninjauan di aplikasi jika tersedia.\n4. Jangan berikan kode OTP atau PIN kepada pihak lain.",14,Color.rgb(210,224,230),false); steps.setPadding(0,dp(18),0,dp(10)); root.addView(steps);
        root.addView(text("Tidak mengirim data nomor ke aplikasi ini.",12,Color.rgb(140,165,175),false));
    }
}
